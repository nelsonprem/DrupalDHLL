<?php

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Serialization\Yaml;
use GuzzleHttp\Exception\RequestException;

/**
 * Implements hook_form().
 */
function dhl_location_finder_form($form, FormStateInterface $form_state) {
  $form['country'] = [
    '#type' => 'textfield',
    '#title' => t('Country'),
    '#required' => TRUE,
  ];

  $form['city'] = [
    '#type' => 'textfield',
    '#title' => t('City'),
    '#required' => TRUE,
  ];

  $form['postal_code'] = [
    '#type' => 'textfield',
    '#title' => t('Postal Code'),
    '#required' => TRUE,
  ];

  $form['submit'] = [
    '#type' => 'submit',
    '#value' => t('Submit'),
  ];

  return $form;
}

/**
 * Form submission handler.
 */
function dhl_location_finder_form_submit($form, FormStateInterface $form_state) {
  $country = $form_state->getValue('country');
  $city = $form_state->getValue('city');
  $postal_code = $form_state->getValue('postal_code');

  // Call the DHL API to get locations.
  try {
    $locations = dhl_get_locations($country, $city, $postal_code);

    // Filter locations based on conditions.
    $filtered_locations = dhl_filter_locations($locations);

    // Output filtered locations in YAML format.
    $yaml_output = Yaml::encode($filtered_locations);
    drupal_set_message($yaml_output);
  } catch (RequestException $e) {
    drupal_set_message(t('Error fetching locations from DHL API. Please try again later.'), 'error');
  }
}

/**
 * Helper function to call the DHL API and get locations.
 */
function dhl_get_locations($country, $city, $postal_code) {
	
  $url = 'https://api-sandbox.dhl.com/location-finder/v1/find-by-address'; 
  // Build the request payload.
  $data = [
    'country' => $country,
    'city' => $city,
    'postal_code' => $postal_code,
  ];
  

  $client = \Drupal::httpClient();
 // $client = \Drupal::httpClient();
  $response = $client->post($url, [
    'json' => $data,
    'headers' => [
      'Content-Type' => 'application/json',
    ],
  ]);

  if ($response->getStatusCode() === 200) {
    $locations = json_decode($response->getBody(), TRUE);
    return $locations;
  } else {
    throw new RequestException('Error fetching locations from DHL API.', $response->getStatusCode());
  }
}

/**
 * Helper function to filter locations based on conditions.
 */
function dhl_filter_locations($locations) {
  $filtered_locations = [];

  foreach ($locations as $location) {
    // Check if the address has an odd number.
    $address_parts = explode(' ', $location['address']);
    $last_address_part = end($address_parts);
    $last_digit = intval(substr($last_address_part, -1));

    // If the last digit is odd, skip this location.
    if ($last_digit % 2 !== 0) {
      continue;
    }

    // Check if the location works on weekends (implement your logic here).
    // For this example, let's assume all locations work on weekends.
    $works_on_weekends = TRUE;

    if ($works_on_weekends) {
      $filtered_locations[] = $location;
    }
  }

  return $filtered_locations;
}
